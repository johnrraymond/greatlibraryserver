Free for personal and commercial use.

https://www.behance.net/gallery/72768953/BITTER-ROSE-FREE-BRUSH-FONT-TEXTURES